ReconAegis - Starter anti-cheat template for FiveM
----------------------------------------------------
Questo pacchetto è un punto di partenza completo che contiene:
- fxmanifest.lua
- server (ban management, webhook, protections)
- client (detection scaffolding, integrity)
- web dashboard (HTML/CSS/JS)
- bans/bans.json sample
- assets (logo)

IMPORTANTE:
- Testare pesantemente in ambiente di prova.
- Le parti "sensibili" devono essere migrate in componenti native/compiled per maggiore sicurezza.
- L'obfuscazione fornita è minima; usare un obfuscator professionale per la produzione.
- Alcune detections client-side sono limitate dalle API FiveM e devono essere affiancate da controlli server-side.

Per richieste aggiuntive (nuove detections, integrazione con database, API di upload per screenshot), chiedimi e posso estendere il progetto.
