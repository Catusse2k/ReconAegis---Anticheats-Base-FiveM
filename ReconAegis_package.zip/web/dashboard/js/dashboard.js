document.getElementById('refresh').addEventListener('click', async () => {
    const list = document.getElementById('banlist');
    list.innerText = 'Caricamento...';
    try {
        const res = await fetch('/bans/bans.json');
        const data = await res.json();
        render(data);
    } catch (e) {
        list.innerText = 'Errore caricamento.';
    }
});

document.getElementById('download').addEventListener('click', () => {
    window.location.href = '/bans/bans.json';
});

function render(data){
    const list = document.getElementById('banlist');
    list.innerHTML = '';
    if(!Array.isArray(data) || data.length===0){ list.innerText = 'Nessun ban presente.'; return; }
    data.slice(-50).reverse().forEach(b => {
        const el = document.createElement('div');
        el.className = 'ban-entry';
        el.innerHTML = `<strong>${b.identifiers and b.identifiers[1] or b.id}</strong> - ${b.reason} <div style="opacity:0.6;font-size:12px">${new Date(b.timestamp*1000).toLocaleString()}</div>`;
        list.appendChild(el);
    });
}
