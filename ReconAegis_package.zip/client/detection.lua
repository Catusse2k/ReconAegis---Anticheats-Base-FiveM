-- client/detection.lua
-- More focused detection logic: silent aim heuristics, noclip signature checks, resource tampering indicators
-- IMPORTANT: Heuristics require tuning. This file contains examples and scaffolding.
local cfg = ReconAegis.config

-- Example: Hook suspicious controls commonly used by mod menus and capture screenshots
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(200)
        -- Example: detect unusual key combos (placeholders)
        if IsControlPressed(0, 289) then -- F2 often used by menus (placeholder)
            -- capture a short gif/screenshot (handled in screenshot.lua)
            TriggerEvent("reconaegis:captureShort", {reason="menu_key_pressed"})
        end
    end
end)

-- Detect rapid teleport / noclip by monitoring velocity vs position changes
local lastPos = nil
Citizen.CreateThread(function()
    while true do
        Citizen.Wait(500)
        local ped = PlayerPedId()
        if ped and ped ~= 0 then
            local pos = GetEntityCoords(ped)
            if lastPos then
                local dist = #(pos - lastPos)
                if dist > 50.0 then
                    -- possible teleport / noclip
                    TriggerServerEvent("reconaegis:clientDetection", {type="noclip_detected", detail=dist})
                end
            end
            lastPos = pos
        end
    end
end)
