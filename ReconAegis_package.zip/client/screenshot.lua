-- client/screenshot.lua
-- Uses built-in FiveM screenshot endpoint if available (screenshotBasic) or custom approach
local cfg = ReconAegis.config

RegisterNetEvent("reconaegis:captureShort", function(data)
    -- Create a quick screenshot and upload to server (server must implement endpoint to accept binary upload)
    if type(data) ~= "table" then data = {reason=tostring(data)} end
    -- Attempt to use screenshotBasic (FiveM), if allowed by server build
    if exports and exports.screenshotBasic then
        exports.screenshotBasic:requestScreenshotUpload("https://your.upload.endpoint/upload", "files[]", function(data)
            TriggerServerEvent("reconaegis:log", {event="screenshot_uploaded", url=data, reason=data.reason})
        end, {quality = 70})
    else
        -- fallback: log event for admins to request further review
        TriggerServerEvent("reconaegis:log", {event="screenshot_failed", reason=data.reason})
    end
end)
