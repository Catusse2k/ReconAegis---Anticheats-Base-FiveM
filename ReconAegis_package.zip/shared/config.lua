-- ReconAegis global configuration (100% configurable)
ReconAegis = ReconAegis or {}

ReconAegis.config = {
    serverName = "ReconAegis Server",
    banOnDetect = true,
    instantBanReasons = {
        "load_launcher_detected",
        "aimbot_detected",
        "godmode_detected",
        "resource_manipulation",
        "anti_dump_triggered"
    },
    webhookURL = "https://discord.example/webhook", -- set your webhook
    screenshotDir = "screenshots",
    checkIntervalSec = 10,
    bannedProcessNames = {"eulen", "skript.gg", "susano", "cheatengine", "menu"},
    bannedResourceHashes = {}, -- fill with server resource file hashes
    maxSuspiciousEvents = 3, -- cycles before auto-ban for suspicious behavior
}
