-- server/protections.lua
-- Server-side protections: validate critical server events, prevent harmful spawns
AddEventHandler("entityCreating", function(entity)
    -- run server-side checks on entity creation, if available
    -- This is a template: expand to check model hashes, positions, etc.
    TriggerEvent("reconaegis:log", {event="entityCreating", entity=entity})
end)

-- Prevent mass vehicle spawn exploit: simple example interception
RegisterNetEvent("reconaegis:requestVehicleSpawn", function(data)
    local src = source
    -- Validate player's permission and spawn limits server-side before creating vehicles
    local allowed = false
    -- Add logic to check groups/roles
    if not allowed then
        TriggerEvent("reconaegis:log", {event="blocked_spawn", source=src, data=data})
        -- punish if obviously malicious
        TriggerEvent("reconaegis:log", {event="action", action="kick", source=src, reason="blocked_spawn"})
        DropPlayer(src, "ReconAegis: unauthorized spawn attempt.")
    end
end)
