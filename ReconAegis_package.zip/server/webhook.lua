-- server/webhook.lua
local cfg = ReconAegis.config

RegisterNetEvent("reconaegis:webhook", function(data)
    local payload = {
        ["username"] = "ReconAegis",
        ["embeds"] = {{
            ["title"] = "ReconAegis Event",
            ["description"] = json.encode(data),
            ["timestamp"] = os.date("!%Y-%m-%dT%H:%M:%SZ")
        }}
    }
    if cfg.webhookURL and cfg.webhookURL ~= "" then
        PerformHttpRequest(cfg.webhookURL, function() end, 'POST', json.encode(payload), { ['Content-Type'] = 'application/json' })
    end
end)
