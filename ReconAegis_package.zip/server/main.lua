-- server/main.lua
local cfg = ReconAegis.config
local bans = require('server/bans')

-- Utility to ban a player with reason (instant if configured)
local function banPlayer(source, reason)
    local id = tostring(source)
    local steam = ""
    for k,v in pairs(GetPlayerIdentifiers(source)) do
        if string.find(v, "steam:") then steam = v break end
    end
    local banRecord = {
        id = id,
        identifiers = GetPlayerIdentifiers(source),
        reason = reason,
        timestamp = os.time(),
    }
    bans.addBan(banRecord)
    DropPlayer(source, "Banned by ReconAegis. Reason: "..reason)
    -- webhook
    TriggerEvent("reconaegis:log", banRecord)
end

-- Listen for validated detections from clients
RegisterNetEvent("reconaegis:clientDetection", function(data)
    local src = source
    if not data or not data.type then return end
    print("[ReconAegis] Detection from client "..src.." type: "..tostring(data.type))
    if cfg.banOnDetect then
        banPlayer(src, data.type)
    end
end)

-- Protect server-side resources: deny unauthorized resource stop
AddEventHandler("onResourceStop", function(name)
    print("[ReconAegis] Resource stopped: "..tostring(name))
    -- if unauthorized, attempt to identify source and ban
    -- Note: FiveM does not provide direct who-stopped-resource; we log and alert admins
    TriggerEvent("reconaegis:log", {event="resource_stop", resource=name, timestamp=os.time()})
end)

-- Event to perform server-side integrity checks on demand
RegisterNetEvent("reconaegis:requestServerIntegrity", function()
    local src = source
    -- Basic example: compare resource list to expected (expand for production)
    TriggerClientEvent("reconaegis:serverIntegrityResponse", src, {ok=true, note="template response"})
end)

-- Simple admin command to list bans (for demo)
RegisterCommand("reconaegis_bans", function(source, args, raw)
    if source == 0 then -- server console
        print(json.encode(bans.getAll()))
    else
        -- return a small list to player (admins should be validated)
        TriggerClientEvent("chat:addMessage", source, {args={"ReconAegis", "Use server console for full ban list."}})
    end
end, true)

-- Logging event
RegisterNetEvent("reconaegis:log", function(data)
    print("[ReconAegis LOG] "..json.encode(data))
    -- optionally: send webhook (handled in server/webhook.lua)
    TriggerEvent("reconaegis:webhook", data)
end)
