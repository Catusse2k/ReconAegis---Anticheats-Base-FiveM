-- server/bans.lua
local banFile = "bans/bans.json"
local M = {}

local function ensureDir()
    local dir = "bans"
    local f = io.open(banFile, "r")
    if not f then
        os.execute("mkdir -p "..dir)
        local fh = io.open(banFile, "w+")
        fh:write("[]")
        fh:close()
    else
        f:close()
    end
end
ensureDir()

function M.getAll()
    local fh = io.open(banFile, "r")
    if not fh then return {} end
    local content = fh:read("*a")
    fh:close()
    local ok, parsed = pcall(function() return json.decode(content) end)
    if not ok then return {} end
    return parsed or {}
end

function M.addBan(entry)
    local bans = M.getAll()
    table.insert(bans, entry)
    local fh = io.open(banFile, "w+")
    fh:write(json.encode(bans))
    fh:close()
end

return M
