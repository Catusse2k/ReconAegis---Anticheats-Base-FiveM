fx_version 'cerulean'
games { 'gta5' }

author 'ReconAegis Team'
description 'ReconAegis - AntiCheat (template). Comprendi ReconAegis nelle stringhe.'
version '1.0.0'

server_scripts {
    'shared/config.lua',
    'server/main.lua',
    'server/webhook.lua',
    'server/bans.lua',
    'server/protections.lua'
}

client_scripts {
    'shared/config.lua',
    'client/main.lua',
    'client/integrity.lua',
    'client/detection.lua',
    'client/screenshot.lua'
}

ui_page 'web/dashboard/index.html'

files {
    'web/dashboard/index.html',
    'web/dashboard/css/style.css',
    'web/dashboard/js/dashboard.js',
    'web/assets/reconaegis_logo.jpg',
    'bans/bans.json'
}
